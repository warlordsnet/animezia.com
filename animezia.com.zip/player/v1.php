<?php 
require('../_config.php');
$id = $_GET['id']; 
$download = $_GET['download']; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "$api/vidcdn/watch/$id");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
 $response = curl_exec($ch);
 $json = json_decode($response, true);
	 curl_close($ch);							  
//$json = file_get_contents("$api/vidcdn/watch/$id");
//$json = json_decode($json, true);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>AnimeZia Player</title>
  <link rel="stylesheet" href="https://player.anikatsu.me/style.css">
  
</head>

<body>


  <style>
    .wrap #player {
        position: absolute;
        height: 100% !important;
        weight: 100 !important;
    }

    .wrap .btn {
        position: absolute;
        top: 15%;
        left: 90%;
        transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        background-color: white;
        color: black;
        font-size: 12px;
        padding: 6px 12px;
        border: 1px solid white;
        cursor: pointer;
        border-radius: 5px;
    }

    @media screen and (max-width:600px) {
        .wrap .btn {
            font-size: 08px;
        }
    }
    </style>

   <div class="wrap">

        <div id="player"></div>
        
    </div>
  <script src='https://player.anikatsu.me/jw.js'></script>
<script type="text/javascript">
  const playerInstance = jwplayer("player");
  playerInstance.setup({
     controls: true,
      sharing: true,
      displaytitle: true,
      displaydescription: true,
      abouttext: "AnimeZia",
      aboutlink: "www.animezia.com",
      
      autostart: true,	  
        ga: {},
   logo: {
        file:
          "https://cdnzia.pages.dev/images/logo2.webp",
        link: "//www.animezia.com/home"
      },
	  playlist: [{
            description: "Episode Title:",
            title: "<?=$id?>",
           
            sources: <?php echo json_encode($json) ?>,
            autostart: true,
        }],
    skin: {
        name: "netflix"
      }             
    });

  playerInstance.on("ready", function () {
      const buttonId = "download-video-button";
      const iconPath =
        "https://cdnzia.pages.dev/images/download.webp";
      const tooltipText = "Download Video";

      // Call the player's `addButton` API method to add the custom button
      playerInstance.addButton(iconPath, tooltipText, buttonClickAction, buttonId);

      // This function is executed when the button is clicked
      function buttonClickAction() {
        const playlistItem = playerInstance.getPlaylistItem();
        const anchor = document.createElement("a");
        const fileUrl = playlistItem.file;
        anchor.setAttribute("href", "<?=$download?>");
        anchor.setAttribute("target", "_blank");
        const downloadName = playlistItem.file.split("/").pop();
        anchor.setAttribute("download", downloadName);
        anchor.style.display = "none";
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
      }
	 

      // Move the timeslider in-line with other controls
      const playerContainer = playerInstance.getContainer();
      const buttonContainer = playerContainer.querySelector(".jw-button-container");
      const spacer = buttonContainer.querySelector(".jw-spacer");
      const timeSlider = playerContainer.querySelector(".jw-slider-time");
      buttonContainer.replaceChild(timeSlider, spacer);

const player = playerInstance;

// display icon
const rewindContainer = playerContainer.querySelector('.jw-display-icon-rewind');
const forwardContainer = rewindContainer.cloneNode(true);
const forwardDisplayButton = forwardContainer.querySelector('.jw-icon-rewind');
forwardDisplayButton.style.transform = "scaleX(-1)";
forwardDisplayButton.ariaLabel = "Forward 10 Seconds"
const nextContainer = playerContainer.querySelector('.jw-display-icon-next');
nextContainer.parentNode.insertBefore(forwardContainer, nextContainer);


// control bar icon
playerContainer.querySelector('.jw-display-icon-next').style.display = 'none'; // hide next button
const rewindControlBarButton = buttonContainer.querySelector(".jw-icon-rewind");
rewindControlBarButton.ariaLabel = "Backward 10 Seconds";
const forwardControlBarButton = rewindControlBarButton.cloneNode(true);
forwardControlBarButton.style.transform = "scaleX(-1)";
forwardControlBarButton.ariaLabel = "Forward 10 Seconds";
rewindControlBarButton.parentNode.insertBefore(forwardControlBarButton, rewindControlBarButton.nextElementSibling);

// add onclick handlers
[forwardDisplayButton, forwardControlBarButton].forEach(button => {
  button.onclick = () => {
    player.seek((player.getPosition() + 10));
  }
})
      // New Features
      console.log(timeSlider);
    });
  </script>
</body>
</html> 